<div id="screen">
  <h1>Hi. I'm default.</h1>
  <p>Don't be sad, I don't mind being nobody. It's okay, really.</p>
</div>
